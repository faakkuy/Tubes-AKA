#include <iostream>
#include "kamus.h"
#include <chrono>

using namespace std;

int main() {
    const int MAX_STUDENTS = 2000;
    Student students[MAX_STUDENTS];

    for (int i = 0; i < MAX_STUDENTS; i++) {
        students[i].name = "Student" + to_string(i + 1);
        students[i].kelas = "Class" + to_string((i % 10) + 1);
        students[i].nilai = (i % 101);
    }

    // Sorting menggunakan Insertion Sort (Menurun)
    cout << "\nData Siswa Setelah Insertion Sort (Menurun):" << endl;
    insertionSort(students, MAX_STUDENTS, false);
    displayStudents(students, MAX_STUDENTS);

    // Membersihkan buffer output
    cout.flush();

    return 0;
}

/*
 cout << "\nData Siswa Setelah Selection Sort (Menurun):" << endl;
    selectionSort(students, MAX_STUDENTS, false);
    displayStudents(students, MAX_STUDENTS);

*/

