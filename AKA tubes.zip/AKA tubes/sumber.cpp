#include <iostream>
#include "kamus.h"

using namespace std;

void displayStudents(Student students[], int n) {
    for (int i = 0; i < n; i++) {
        cout << students[i].name << " " << students[i].kelas << " " << students[i].nilai << endl;
    }
}

// Prosedur Selection Sort (Menurun)
void selectionSort(Student students[], int n, bool ascending) {
    for (int pass = 1; pass < n; pass++) {
        int extremeIdx = pass - 1;
        for (int j = pass; j < n; j++) {
            if ((ascending && students[j].nilai < students[extremeIdx].nilai) ||
                (!ascending && students[j].nilai > students[extremeIdx].nilai)) {
                extremeIdx = j;
            }
        }
        Student temp = students[extremeIdx];
        students[extremeIdx] = students[pass - 1];
        students[pass - 1] = temp;
    }
}

// Prosedur Insertion Sort (Menurun)
void insertionSort(Student students[], int n, bool ascending) {
    for (int pass = 1; pass < n; pass++) {
        Student temp = students[pass];
        int j = pass;

        while (j > 0 && ((!ascending && students[j - 1].nilai < temp.nilai) ||
                         (ascending && students[j - 1].nilai > temp.nilai))) {
            students[j] = students[j - 1];
            j = j - 1;
        }
        students[j] = temp;
    }
}


