#ifndef KAMUS_H_INCLUDED
#define KAMUS_H_INCLUDED
#include <iostream>
#include <string>
using namespace std;

struct Student {
    string name;
    string kelas;
    double nilai;
};


void selectionSort(Student students[], int n, bool ascending);
void displayStudents(Student students[], int n);
void insertionSort(Student students[], int n, bool ascending);
#endif // KAMUS_H_INCLUDED
